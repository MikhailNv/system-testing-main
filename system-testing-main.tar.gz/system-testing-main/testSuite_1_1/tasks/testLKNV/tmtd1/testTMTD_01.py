import pexpect

class Tmtd1:

    def adding_rules(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('uname -a')
        child.expect_exact("]#")
        system = child.before.decode('utf-8').split()[-5]
        if system == "x86_64" or system == "amd64":
            child.sendline('echo "-a always,exit -F arch=b64 -F euid=0 -S execve -k privileged" >> /etc/audit/rules.d/20-privileged.rules')
            child.expect_exact("#")
        elif system == "i686":
            child.sendline('echo "-a always,exit -F arch=b32 -F euid=0 -S execve -k privileged" >> /etc/audit/rules.d/20-privileged.rules')
            child.expect_exact("#")
        else:
            child.sendline('echo "-a always,exit -F euid=0 -S execve -k privileged" >> /etc/audit/rules.d/20-privileged.rules')
            child.expect_exact("#")
        return True

    def user_attributes(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('auditctl -w /etc/tcb -p w -k tcb')
        child.expect_exact("#")
        child.sendline('useradd -e 2025-05-30 ivk5')
        child.expect_exact("#")
        child.sendline('cat /etc/tcb/ivk5/shadow')
        child.expect_exact("#")
        if 'ivk5:' in child.before.decode('utf-8').split()[2]:
            child.sendline('passwd ivk5')
            child.expect_exact("password")
            child.sendline('Qwerty1917!')
            child.expect_exact("password")
            child.sendline('Qwerty1917!')
            child.expect_exact("#")
            child.sendline('cat /etc/tcb/ivk5/shadow')
            child.expect_exact("#")
            if len(child.before.decode('utf-8').split()[2][5:-17]) == 60:
                child.sendline('gpasswd -a ivk5 wheel')
                child.expect_exact("#")
                child.sendline('id ivk5')
                child.expect_exact("#")
                if 'wheel' in child.before.decode('utf-8').split()[4]:
                    child.sendline('chmod a+r /etc/login.defs')
                    child.expect_exact("#")
                    child.sendline('su - ivk1')
                    child.expect_exact("$")
                    child.sendline('/usr/sbin/useradd ivk4')
                    child.expect_exact("$")
                    if 'useradd: PAM:' in  child.before.decode('utf-8').split('\r\n')[1]:
                        return True
                    else:
                        raise Exception("Authentication error")
                else:
                    raise Exception("Error adding a user to a group")
            else:
                raise Exception("Error adding a password to the user")
        else:
            raise Exception("User creation error")

    def changing_system_object(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('mknod /dev/tdev b 0 0')
        child.expect_exact("#")
        child.sendline('ls -l /dev/tdev')
        child.expect_exact("#")
        if '/dev/tdev' in child.before.decode('utf-8').split()[12]:
            child.sendline('su - ivk1')
            child.expect_exact("$")
            child.sendline('mknod /dev/test b 0 0')
            child.expect_exact("$")
            if 'mknod: /dev/test:' in child.before.decode('utf-8').split('\r\n')[1]:
                child.sendline('mv /dev/tdev /dev/test')
                child.expect_exact("$")
                if 'mv: ' in child.before.decode('utf-8').split('\r\n')[1]:
                    child.sendline('exit')
                    child.expect_exact("#")
                    child.sendline('rm /dev/test')
                    child.expect_exact("#")
                    return True
                else:
                    raise Exception("Mv rights error")

            else:
                raise Exception("Mknod rights error")

        else:
            raise Exception("Mknod error")

    def attribute_modification(self):
        child = pexpect.spawn("su - ivk1")
        child.expect_exact("$")
        child.sendline('gpasswd -d ivk5 wheel')
        child.expect_exact("$")
        if '-bash: /usr/bin/gpasswd:' in child.before.decode('utf-8').split('\r\n'):
            child.sendline("exit")
            child.expect_exact("#")
            print(child.sendline("whoami"))
            child.sendline('gpasswd -d ivk5 wheel')
            child.expect_exact("#")
            return True
        else:
            raise Exception("Gpasswd error")



cr = Tmtd1()
#print(cr.adding_rules())
print(cr.attribute_modification())
