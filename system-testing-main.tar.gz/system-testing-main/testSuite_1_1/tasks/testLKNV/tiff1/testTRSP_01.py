import pexpect, os, sys, time
sys.path.insert(1, "/home/officer/Documents/system-testing-main/testSuite_1_1/tasks/testARMH")
from test_gui_program import GuiProgram

class Tiff1:

    def check_file(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('cat /etc/control++/control++.conf')
        child.expect_exact("#")

