import pexpect

class Tmof1:

    def adding_rules(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('uname -a')
        child.expect_exact("]#")
