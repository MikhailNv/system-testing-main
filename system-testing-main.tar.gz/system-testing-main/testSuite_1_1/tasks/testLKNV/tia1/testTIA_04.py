import pexpect, os, sys, time
sys.path.insert(1, "/home/officer/Documents/system-testing-main/testSuite_1_1/tasks/testARMH")
from test_gui_program import GuiProgram

class Tia4:
    def __init__(self):
        self.child = pexpect.spawn("su - officer")
        self.child.expect_exact("$")

    def process(self):
        self.child.sendline("mc")
        self.child.expect_exact("$")
        child = pexpect.spawn("su - officer")
        child.expect_exact("$")
        child.sendline('ps -e | grep mc')
        child.expect_exact("$")
        out = child.before.decode('utf-8').split()
        if 'pts' in out[10]:
            child.sendline(f'stat /proc/{out[9]}')
            child.expect_exact("$")
            if len(child.before.decode('utf-8').split('\r\n')[1:-1]) == 9:
                self.child.sendline("exit")
                self.child.expect_exact("$")
                return True
            else:
                self.child.sendline("exit")
                self.child.expect_exact("$")
                raise Exception("Property view error process.")
        else:
            self.child.sendline("exit")
            self.child.expect_exact("$")
            raise Exception("Process start error.")
