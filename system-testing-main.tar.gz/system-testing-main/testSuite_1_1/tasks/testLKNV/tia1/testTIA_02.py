import pexpect

class Tia2:

    def file_setting(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('cat /dev/null > /etc/passwdqc.conf')
        child.expect_exact("#")
        child.sendline("echo 'min=disabled,24,11,8,7' >> /etc/passwdqc.conf")
        child.expect_exact("#")
        child.sendline("echo 'max=40' >> /etc/passwdqc.conf")
        child.expect_exact("#")
        child.sendline("echo 'passphrase=3' >> /etc/passwdqc.conf")
        child.expect_exact("#")
        child.sendline("echo 'match=4' >> /etc/passwdqc.conf")
        child.expect_exact("#")
        child.sendline("echo 'similar=deny' >> /etc/passwdqc.conf")
        child.expect_exact("#")
        child.sendline("echo 'random=47' >> /etc/passwdqc.conf")
        child.expect_exact("#")
        child.sendline("echo 'enforce=everyone' >> /etc/passwdqc.conf")
        child.expect_exact("#")
        child.sendline("echo 'retry=3' >> /etc/passwdqc.conf")
        child.expect_exact("#")
        child.sendline("cat /etc/passwdqc.conf")
        child.expect_exact("#")
        if len(child.before.decode('utf-8').split('\r\n')[1:-1]) == 8:
            return True
        else:
            raise Exception("File write error")

    def change_passwd(self):
        child = pexpect.spawn("su - ivk1")
        child.expect_exact("$")
        child.sendline("passwd ivk1")
        child.expect_exact("current password")
        child.sendline("Wels082017!")
        child.expect_exact("password")
        child.sendline("tea")
        child.expect_exact("too short")
        child.expect_exact("password")
        child.sendline("Wels082017")
        child.expect_exact("length")
        child.expect_exact("password")
        child.sendline("Wels082017!")
        child.expect_exact("old one")
        child.expect_exact("$")
        return True

    def successful_passwd_update(self):
        child = pexpect.spawn("su - ivk1")
        child.expect_exact("$")
        child.sendline("passwd ivk1")
        child.expect_exact("current password")
        child.sendline("Wels082017!")
        child.expect_exact("password")
        print(1)
        child.sendline("qwerty1tia2!")
        child.expect_exact("password")
        print(2)
        child.sendline("qwerty1tia2!")
        child.expect_exact("$")
        return True

