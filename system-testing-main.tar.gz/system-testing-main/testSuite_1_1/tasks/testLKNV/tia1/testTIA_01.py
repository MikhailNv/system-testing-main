import pexpect

class Tia1:

    def create_user(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('useradd -e 2022-6-1 user2')
        child.expect_exact("#")
        return True
    
    def date_info(self, key):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('cat /etc/tcb/user2/shadow')
        child.expect_exact("#")
        if 'user2:!!' in child.before.decode('utf-8').split('\r\n')[1] and key == 1:
            return True
        elif len(child.before.decode('utf-8').split('\r\n')[1][6:-17]) == 60 and key == 2:
            return True
        else:
            raise Exception("Error in finding expiration date actions")

    def set_passwd(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('passwd user2')
        child.expect_exact("password:")
        child.sendline('qwerty')
        child.expect_exact("password:")
        child.sendline('qwerty')
        child.expect_exact("#")
        return True
    
    def user_attributes(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('id user2')
        child.expect_exact("#")
        if 'uid' in child.before.decode('utf-8').split('\r\n')[1] and 'gid' in child.before.decode('utf-8').split('\r\n')[1] and 'groups' in child.before.decode('utf-8').split('\r\n')[1]:
            return True
        else:
            raise Exception("Error viewing user attributes")
