import pexpect

class Trsp1:

    def disable_autorun(self, command1, command2):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline(f'systemctl {command1} sshd')
        child.expect_exact("#")
        child.sendline(f'systemctl {command2} httpd2')
        child.expect_exact("#")
        child.sendline('systemctl --system -t service list-unit-files | grep sshd')
        child.expect_exact("#")
        if command1 + 'd' == child.before.decode('utf-8').split()[10]:
            child.sendline('systemctl --system -t service list-unit-files | grep httpd2')
            child.expect_exact("#")
            if command2 + 'd' == child.before.decode('utf-8').split()[10]:
                return True
            else:
                raise Exception("Error changing httpd2 service autostart")
        else:
            raise Exception("Error changing sshd service autostart")
