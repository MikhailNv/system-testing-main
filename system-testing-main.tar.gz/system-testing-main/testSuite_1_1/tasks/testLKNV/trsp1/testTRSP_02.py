import pexpect, os, sys, time
sys.path.insert(1, "/home/officer/Documents/system-testing-main/testSuite_1_1/tasks/testARMH")
from test_gui_program import GuiProgram

class Trsp2:

    def check_file(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('cat /etc/control++/control++.conf')
        child.expect_exact("#")
        if '[wl]' in child.before.decode('utf-8').split('\r\n') and '[blacklist]' not in child.before.decode('utf-8').split('\r\n'):
            child.sendline('echo "[blacklist]" >> /etc/control++/control++.conf')
            child.expect_exact("#")
            child.sendline('echo "permissions = bl" >> /etc/control++/control++.conf')
            child.expect_exact("#")
            return True
        else:
            child.sendline('cp /dev/null /etc/control++/control++.conf')
            child.expect_exact("?")
            child.sendline("y")
            child.expect_exact("#")
            child.sendline('echo "[wl]" >> /etc/control++/control++.conf')
            child.expect_exact("#")
            child.sendline('echo "permissions = wl" >> /etc/control++/control++.conf')
            child.expect_exact("#")
            child.sendline('echo "[blacklist]" >> /etc/control++/control++.conf')
            child.expect_exact("#")
            child.sendline('echo "permissions = bl" >> /etc/control++/control++.conf')
            child.expect_exact("#")
            return True

    def audit_setting(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('auditctl -a always,exit -F arch=b32 -S open,openat,execve -F exit=-EACCES -F key="AVC avc: "')
        child.expect_exact("#")
        child.sendline('auditctl -a always,exit -F arch=b32 -S open,openat,execve -F exit=-EPERM -F key="AVC avc: "')
        child.expect_exact("#")
        child.sendline('auditctl -a always,exit -F arch=b64 -S open,openat,execve -F exit=-EACCES -F key="AVC avc: "')
        child.expect_exact("#")
        child.sendline('auditctl -a always,exit -F arch=b64 -S open,openat,execve -F exit=-EPERM -F key="AVC avc: "')
        child.expect_exact("#")
        child.sendline('auditctl -l')
        child.expect_exact("#")
        if len(child.before.decode('utf-8').split('\r\n')[1:-1]) == 6:
            return True
        else:
            raise Exception("Error adding rules")

    def blacklist_setting(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('touch /etc/control++/permissions/bl')
        child.expect_exact("#")
        child.sendline('echo "# You can use comments like this one" >> /etc/control++/permissions/bl')
        child.expect_exact("#")
        child.sendline('echo "[blacklist]" >> /etc/control++/permissions/bl')
        child.expect_exact("#")
        child.sendline('echo "path = /etc/control++/blacklist" >> /etc/control++/permissions/bl')
        child.expect_exact("#")
        child.sendline('touch /etc/control++/blacklist')
        child.expect_exact("#")
        child.sendline('echo "/usr/bin/firefox" >> /etc/control++/blacklist')
        child.expect_exact("#")
        child.sendline('control++ blacklist')
        child.expect_exact("#")
        child.sendline('/usr/bin/firefox')
        child.expect_exact("#")
        child.sendline('')
        child.expect_exact("#")
        if 'Permission denied' in child.before.decode('utf-8').split('\r\n')[1]:
            return True
        else:
            raise Exception("Error with setting control++ rules")

    def reset_blacklist(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('control++ reset')
        child.expect_exact("#")
        child.sendline('cat /dev/null > /etc/control++/blacklist')
        child.expect_exact("#")
        gp = GuiProgram()
        if gp.check_running_app("/usr/bin/firefox"):
            return True
        else:
            raise Exception("Error with running app")

    def whitelist_setting(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('cat /dev/null > /etc/control++/permissions/wl')
        child.expect_exact("#")
        child.sendline('echo "# You can use comments like this one" >> /etc/control++/permissions/wl')
        child.expect_exact("#")
        child.sendline('echo [whitelist] >> /etc/control++/permissions/wl')
        child.expect_exact("#")
        child.sendline('echo path = \'\"/etc/control++/white_list\"\' >> /etc/control++/permissions/wl')
        child.expect_exact("#")
        child.sendline('echo base_dir = \'\"/\"\' >> /etc/control++/permissions/wl')
        child.expect_exact("#")
        child.sendline('echo excluded_paths = \'\"boot\"\', \'\"dev\"\', \'\"home\"\', \'\"lost+found\"\', \'\"media\"\', \'\"mnt\"\', \'\"proc\"\', \'\"run\"\', \'\"selinux\"\', \'\"srv\"\', \'\"sys\"\', \'\"tmp\"\', \'\"var\"\' >> /etc/control++/permissions/wl')
        child.expect_exact("#")
        child.sendline('echo "mode_for_dirs = *********" >> /etc/control++/permissions/wl')
        child.expect_exact("#")
        child.sendline('bash /etc/control++/wl.sh')
        child.expect_exact("#")
        child.sendline('control++ reset')
        child.expect_exact("#")
        child.sendline('sed -i s./usr/bin/firefox.//usr/bin/firefox. /etc/control++/white_list')
        child.expect_exact("#")
        child.sendline('control++ wl')
        child.expect_exact("'permissions' unit")
        while True:
            i = child.expect_exact(["#", pexpect.TIMEOUT])
            if i == 0:
                break
            else:
                continue
        if "Current mode is 'wl'" == child.before.decode('utf-8').split('\r\n')[2]:
            child.sendline('sed -i s.//usr/bin/firefox./usr/bin/firefox. /etc/control++/white_list')
            child.expect_exact("#")
            child.sendline('control++ reset')
            child.expect_exact("#")
            return True
        else:
            raise Exception("Error with setting 'wl' mode")



#cp = Trsp()
#print(cp.check_file())
#print(cp.audit_setting())
#print(cp.blacklist_setting())
#print(cp.reset_blacklist())
#print(cp.whitelist_setting())

