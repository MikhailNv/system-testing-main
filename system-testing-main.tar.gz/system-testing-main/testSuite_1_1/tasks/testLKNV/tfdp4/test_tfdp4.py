import pexpect

class Erasing:

    def examination(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('cd /home/ivk1')
        child.expect_exact("#")
        child.sendline('echo test > test')
        child.expect_exact("#")
        child.sendline('ls')
        child.expect_exact("#")
        if 'test' in child.before.decode('utf-8').split():
            child.sendline('cat test')
            child.expect_exact("#")
            if 'test' == child.before.decode('utf-8').split()[2]:
                return True
            else:
                raise Exception("File write error")
        else:
            raise Exception("File creation error")

    def log_file(self):
        child = pexpect.spawn("su -")
        child.expect_exact("#")
        child.sendline('cd /home/ivk1')
        child.expect_exact("#")
        child.sendline('strace -f -o log -e trace=open,write s_rm test')
        child.expect_exact("#")
        child.sendline('grep -c write log')
        child.expect_exact("#")
        if child.before.decode('utf-8').split()[4].isdigit():
            child.sendline('mkdir -p L1dir/L2dir')
            child.expect_exact("#")
            child.sendline('echo content > L1dir/L2dir/L2file')
            child.expect_exact("#")
            child.sendline('strace -f -o sfill.log -e trace=open,write s_fill /home/ivk1/L1dir/L2dir')
            child.expect_exact("#")
            child.sendline('grep -c write sfill.log')
            child.expect_exact("#")
            if child.before.decode('utf-8').split()[4].isdigit():
                child.sendline('rm -R test')
                child.expect_exact("?")
                child.sendline('yes')
                child.expect_exact("#")
                return True
            else:
                raise Exception("Log file error")
        else:
            raise Exception("Log file error")