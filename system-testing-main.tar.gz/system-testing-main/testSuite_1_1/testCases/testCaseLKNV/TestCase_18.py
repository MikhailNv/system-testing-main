import os, sys
sys.path.insert(1, "/home/officer/Documents/system-testing-main/testSuite_1_1/tasks/testLKNV/tia1")
from testTIA_01 import Tia1

cr1 = Tia1()
      
def test_create_user():
    assert (cr1.create_user() == True) 
    
def test_first_date_info():
    assert (cr1.date_info(1) == True)
    
def test_set_passwd():
    assert (cr1.set_passwd() == True)
    
def test_second_date_info():
    assert (cr1.date_info(2) == True)

def test_user_attributes():
    assert (cr1.user_attributes() == True)

