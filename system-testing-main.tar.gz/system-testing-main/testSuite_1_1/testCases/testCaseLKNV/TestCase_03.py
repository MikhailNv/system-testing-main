import os, sys
sys.path.insert(1, os.path.join(sys.path[0], "testSuite_1_1/tasks/testLKNV/tfdp1"))
from test03 import CheckingFirstGID

cr = CheckingFirstGID()

def test_access():
    assert (cr.access() == True)

def test_create_file():
    assert (cr.create_file() == True)

def test_setting_first_new_rights():
    assert (cr.setting_new_rights('rx') == True)

def test_operations_on_files():
    assert (cr.operations_on_files() == True)

def test_setting_second_new_rights():
    assert (cr.setting_new_rights('w') == True)

def test_check_rights_for_ivk2():
    assert (cr.check_rights_for_ivk2() == True)