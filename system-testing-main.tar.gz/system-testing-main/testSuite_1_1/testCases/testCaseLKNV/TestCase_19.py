import os, sys
sys.path.insert(1, "/home/officer/Documents/system-testing-main/testSuite_1_1/tasks/testLKNV/tia1")
from testTIA_02 import Tia2

cr1 = Tia2()

def test_file_setting():
    assert (cr1.file_setting() == True)  

def test_change_passwd():
    assert (cr1.change_passwd() == True) 
    
def test_successful_passwd_update():
    assert (cr1.successful_passwd_update() == True)

