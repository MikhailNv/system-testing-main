import os, sys
sys.path.insert(1, "/home/officer/Documents/system-testing-main/testSuite_1_1/tasks/testLKNV/tia1")
from testTIA_04 import Tia4

cr1 = Tia4()

def test_process():
    assert (cr1.process() == True)
