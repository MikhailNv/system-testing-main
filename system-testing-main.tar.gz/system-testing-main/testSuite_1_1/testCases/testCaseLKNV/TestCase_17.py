import os, sys
sys.path.insert(1, "/home/officer/Documents/system-testing-main/testSuite_1_1/tasks/testLKNV/trsp1")
from testTRSP_01 import Trsp1
from testTRSP_02 import Trsp2

cr1 = Trsp1()
cr2 = Trsp2()

def test_sshd_disable():
    assert (cr1.disable_autorun('disable', 'enable') == True)

def test_httpd_disable():
    assert (cr1.disable_autorun('enable', 'disable') == True)

def test_check_file():
    assert (cr2.check_file() == True)

def test_audit_setting():
    assert (cr2.audit_setting() == True)

def test_blacklist_setting():
    assert (cr2.blacklist_setting() == True)

def test_reset_blacklist():
    assert (cr2.reset_blacklist() == True)

def test_whitelist_setting():
    assert (cr2.whitelist_setting() == True)

