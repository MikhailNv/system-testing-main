import os, sys
sys.path.insert(1, os.path.join(sys.path[0], "testSuite_1_1/tasks/testLKNV/tfdp4"))
from test_tfdp4 import Erasing

cr = Erasing()

def test_examination():
    assert (cr.examination() == True)

def test_log_file():
    assert (cr.log_file() == True)
